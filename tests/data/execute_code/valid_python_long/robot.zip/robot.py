"""A long, valid Python program."""
from time import sleep

print("Starting")
for i in range(10):
    print(i)
    sleep(1)
print("Finished")
