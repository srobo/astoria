import os

print(os.environ['EXAMPLE_ENV_VAR'])