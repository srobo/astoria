"""A short, valid Python program."""
print("Hello World")
